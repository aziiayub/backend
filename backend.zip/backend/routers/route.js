import express from 'express';
//import { getUser } from '../../frontend/src/services/api.js';
import {getUser,addUser,getUserById,editUser,deleteUser} from '../controllers/getCustomer.js';


//Router
const route = express.Router();


//Get data fromdb route
route.get('/',getUser);

//Send data to db
route.post('/add',addUser);

//Edit data from db 
route.get('/:id',getUserById);
route.put('/:id',editUser);

//Delete Customer By id 
route.delete('/:id',deleteUser);



export default route;





