import mongoose from "mongoose";
import autoIncrement from 'mongoose-auto-increment';

const userScheema = mongoose.Schema({
    customerNAme: String,
    phone: Number,
    address: String,
    dateBooking: String,
    dateReturn: String,
    lengthKamees: Number,
    lengthBazo: Number,
    lengthTira: Number,
    lengthGala: Number,
    lengthChast: Number,
    lengthbackbon: Number,
    lengthGhara: Number,
    lengthShalwar: Number,
    lengthPancha: Number,
    shalwarPakit: Number,
});

autoIncrement.initialize(mongoose.connection);
userScheema.plugin(autoIncrement.plugin, 'user');
const user =  mongoose.model('user',userScheema);

export default user;